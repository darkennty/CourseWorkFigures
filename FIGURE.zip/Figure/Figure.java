package Figure;
public class Figure {

    public boolean check() {
        System.out.println("The figure is figure");
        return false;
    }
    public void perimeter() {
        System.out.println("The figure has no perimeter");
    }

    public void area() {
        System.out.println("The figure has no area");
    }
}
